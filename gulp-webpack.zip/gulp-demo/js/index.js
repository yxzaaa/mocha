$(function(){
    $('#box1').click(function(){
        $('#box2').slideToggle(5000);
    });
});